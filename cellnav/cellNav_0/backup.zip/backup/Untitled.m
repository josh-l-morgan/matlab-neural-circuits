

fList = matlab.codetools.requiredFilesAndProducts(getHisto)
