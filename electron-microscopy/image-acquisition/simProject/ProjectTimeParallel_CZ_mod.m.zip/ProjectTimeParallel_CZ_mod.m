clear all

%% Data Set variables
sectionThickness = .025;
xyResolution = .004;
zLengths = 100: 100: 1000; %length in microns
xLengths = zLengths;%[ 1 1 1 1 1] * 300; %xy length in microns
yLengths = zLengths;%[ 1 1 1 1 1 ] * 300;

%% Tissue Prep Numbers
BlockPrepTime = 7 * 24 * 60 * 60;
SectionsCutPerSec = 0.02; %% Cutting speed
SectionsStainedPerSec = 100000000; %% Currently set large for en block staining. 
WaferConstructionTime = 30 * 60;
SectionsPerWafer = 200;

%% Imaging Prep Time
SectionMapTime = 60; %% Seconds required to map each section
WaferChangeTime = 15 * 60 ; % Seconds for changing Wafers

%% Imaging Time
PixelDwell = 50 * 10 ^ -9; %% seconds
PixNumX = 12 / xyResolution; %% X Dimension of subTile
PixNumY = 10 / xyResolution;
BeamNumber = 61;

% CZMM: Backlash Time only includes a single aspect of scan overhead. I
% suggest to introduce a number "ScanOverhead" instead that also includes
% overhead like Tile, Image & Edge overlapping, given on % of the pure scan
% This Scan Overhead is between  6% and 13% of the pure scan time for the 
% suggested Alpha-Tool & 1mm^3 Sample configuration. 
% (The Sample must be overlapped by the 61 Beams)
% 
% your old value: BackLashTime = 1 * 10^ -10; % ?
ScanOverhead = 0.13;% relative to Scan Time
TilePix = BeamNumber * PixNumX * PixNumY;

Section2SectionTime = 1; % seconds between Planes
SettlingTime = .5;
MovingTime = 0.01;
AutoFocusTime = 3; % delay for tile scan due to autofocus
AutoFocusFrequency = 1; % number of times to autofocus / num tiles
AutoStigTime = 3;
AutoStigFrequency = 1;
Tile2TileSoftwareTime = 0;
Overhead = 0; % Mystery/Software time cost for each tile

RetakeFrequency = 0.01;

%% Tissue Size
xyPixels = (xLengths / xyResolution) .* (yLengths / xyResolution);  % number of pixels per plane
Sections = zLengths / sectionThickness; % number of planes

%%TissuePrepTime
TissuePrepTime = BlockPrepTime ...
    + Sections / SectionsCutPerSec ...
    + Sections / SectionsStainedPerSec ...
    + WaferConstructionTime * Sections/SectionsPerWafer;

%%ImagePrepTime
ImagingPrepTime = SectionMapTime * Sections ...
    + WaferChangeTime;

%%ImagingTime
NumTiles = (fix(xyPixels / TilePix)+1) .* Sections; % Assuming Maximum efficiency ROI

TileTime = (1 + ScanOverhead) * PixelDwell * PixNumX * PixNumY ...
    + Overhead;

Tile2TileTime = 5; % CZMM: using proposed spec value instead of detailed calculation (until autofocus frequency is clear)
%SettlingTime + MovingTime ...
%    + Tile2TileSoftwareTime ...
%    + AutoFocusTime * AutoFocusFrequency ...
%    + AutoStigTime * AutoStigFrequency;

RetakeTime = NumTiles * RetakeFrequency ...  
    * (TileTime + Tile2TileTime + Section2SectionTime); %Assumes automated failure identification

ImagingTime = TileTime * NumTiles ...
    + Section2SectionTime * Sections ...
    + Tile2TileTime * NumTiles;%...
    + RetakeTime;


%% Show Times
subplot(1,5,2:5)
sec2day = 1/60/60/24;
plot(zLengths,TissuePrepTime * sec2day,'r')
hold on
plot(zLengths,ImagingPrepTime * sec2day,'g')
plot(zLengths,(ImagingTime)* sec2day,'m')
plot(zLengths,(ImagingTime + ImagingPrepTime)* sec2day,'b')
hold off

subplot(1,5,1)
bar(TileTime + Tile2TileTime,'r')
hold on
bar(TileTime,'b')
hold off

%% Show data
