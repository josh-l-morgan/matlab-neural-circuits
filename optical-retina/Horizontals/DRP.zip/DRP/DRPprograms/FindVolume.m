%% find volume of sphere within rectangular solid

siz=[100 200 10]

%% find volume


R=10;
Vs=4/3 * pi * R^3;


%% Volume of slice from sphere is pi(2xr - x^2)*(delta)x