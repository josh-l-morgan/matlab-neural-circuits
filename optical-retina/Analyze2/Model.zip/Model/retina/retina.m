

%%Arange CBs into mosaics.
%%Tile territories
%%Assign Connectivity
%%Define synapse weight

numConeL=11;

ConeL.pos=mosaic(numConeL)



CB.pos
