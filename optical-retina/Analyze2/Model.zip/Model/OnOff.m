
OO=rand(2,1)*100;

